import { ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatTable } from '@angular/material/table';
import { Observable } from 'rxjs';
import { questionType } from '../model/questions';
import { DataService } from '../services/data.service';
import {CdkDragDrop, moveItemInArray, transferArrayItem, CdkDragHandle} from '@angular/cdk/drag-drop';

@Component({
  selector: 'app-edit-form',
  templateUrl: './edit-form.component.html',
  styleUrls: ['./edit-form.component.scss']
})
export class EditFormComponent implements OnInit {
  @ViewChild('table')
  table!: MatTable<questionType>;
  disableBtn = false;
  form = new FormGroup({
    name : new FormControl(null, Validators.required),
    label : new FormControl(null, Validators.required),
    type : new FormControl(null, Validators.required),
    validators : new FormControl(null, Validators.required)
 });
  addRowSelected = false;
  displayedColumns: string[] = ['Reorder','Name','Label', 'Type', 'Isrequired', 'Actions'];
  dataSource : any;
  original_data: any;

  constructor(private _dataService: DataService, private fb: FormBuilder, protected cd: ChangeDetectorRef,) {}
  ngOnInit(): void {
    this._dataService.getJSON().subscribe((res) => {
      this.original_data = JSON.parse(JSON.stringify(res.controls));
      this.dataSource = this.original_data;
    });
  }
  removeRow(id: any) {
    this.dataSource = this.dataSource.filter((u : any) => u.name !== id);
  }
  doneRow() {
    if(this.form.valid) {
      let newRow: questionType = {
        "name": this.form.controls['name'].value,
        "label": this.form.controls['label'].value,
        "value": '',
        "type": this.form.controls['type'].value,
        "validators": {
          "required": this.form.controls['validators'].value,
          "minLength": 10
        }
      };
      this.removeRow('');
      this.addRowSelected = false;
      this.dataSource = [...this.dataSource,newRow];
      let obj = {
        controls : this.dataSource
      }
      this._dataService.setData(obj);
      this.disableBtn = false;
      } else {
   
    }
    
  }
  addRow() {
    this.addRowSelected = true;
    const newRow: questionType = {
      "name": "",
      "label": "",
      "value": "",
      "type": "",
      "validators": {
        "required": false,
        "minLength": 10
      }
    };
    this.dataSource = [...this.dataSource,newRow];
    this.disableBtn = true;
    }
    dropTable(event: CdkDragDrop<questionType[]>) {
      const prevIndex = this.dataSource.findIndex((d:any) => d === event.item.data);
      moveItemInArray(this.dataSource, prevIndex, event.currentIndex);
      this.table.renderRows();
      this.dataSource = [...this.dataSource];
      let obj = {
        controls : this.dataSource
      }
      this._dataService.setData(obj);
      this.dataSource = [...this.dataSource]
    }
}
