import { Component, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-simple-survey-form',
  templateUrl: './simple-survey-form.component.html',
  styleUrls: ['./simple-survey-form.component.scss'],
})
export class SimpleSurveyFormComponent implements OnInit {
  isVisible: any;
  isSelected: boolean = true;
  ngOnInit(): void {
   
  }
 
 
}
