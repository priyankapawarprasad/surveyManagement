import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SimpleSurveyFormComponent } from './simple-survey-form.component';

describe('SimpleSurveyFormComponent', () => {
  let component: SimpleSurveyFormComponent;
  let fixture: ComponentFixture<SimpleSurveyFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SimpleSurveyFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SimpleSurveyFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
