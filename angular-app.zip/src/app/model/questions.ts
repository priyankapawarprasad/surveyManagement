
export interface questionType {
    "name": string,
    "label": string,
    "value": string,
    "type": string,
    "validators": {
      "required": boolean,
      "minLength": number
    }
  }
export const questionTypeColumns = [ 
  {
    key: 'Reorder',
    type: 'string',
    label: '',
  },
    {
      key: 'Name',
      type: 'string',
      label: '',
    },
    {
      key: 'Label',
      type: 'string',
      label: 'First Name',
    },
    {
      key: 'Type',
      type: 'string',
      label: 'Type',
    },
    {
      key: 'Isrequired',
      type: 'string',
      label: 'Isrequired',
    },
    {
      key: 'Actions',
      type: 'string',
      label: 'Date of Birth',
    }
  ];