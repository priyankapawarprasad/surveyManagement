import { Component } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { DataService } from './services/data.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  questionsData : any;
  title = 'app';
  constructor(private _dataService: DataService, private fb: FormBuilder) {}
  ngOnInit() {
    this._dataService.getJSON().subscribe((res) => {
      this._dataService.setData(res);
    });
  }
}
