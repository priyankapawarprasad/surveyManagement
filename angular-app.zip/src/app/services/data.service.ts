import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  private updatedQuestionsData = new Subject<any>();
  constructor(private http: HttpClient) {}
  public getJSON(): Observable<any> {
    return this.http.get('./assets/config/survery_questions.json');
  }
  public setData(val : any) {
    this.updatedQuestionsData.next({ val });
  }
  public getData(): Observable<any> {
    return this.updatedQuestionsData.asObservable();
}
}
